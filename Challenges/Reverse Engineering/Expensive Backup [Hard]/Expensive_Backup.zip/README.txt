Your file was encrypted!
Send 1 BTC to this wallet: [Deleted]
In comment write your ID_1 and ID_2
ID1 = 55817cbbe921f8016f19d1201533f8cf4628548ba169d5be81abde640f499909
ID2 = 2edb8f847d627e2d899893bc83ac1b5164943e79ba74dd8e4386146d2e4ed984
